# 🚀 Stateless Django App — "Session Ki Jhanjhat Khatam!"

> **Stateless = Har request apne aap mein poori.**  
> Koi session, koi yaad-dasht store karne ki zaroorat nahi.  
> Simple. Scalable. Reliable.

---

## 📦 What is this?

A fully **stateless Django app** inspired by the concept of moving from stateful (session-based) to stateless architecture.

### ❌ Stateful (Purana MCP Style)
```
Client → Server: "Mujhe data do"
Server → Client: "Session ID: abc123 rakho cookie mein"
Client → Server: "Aur data do (cookie: abc123)"
Server: "Session store check karta hoon... haan, yeh wahi user hai."
```
**Problem:** Sticky sessions, complex load balancing, server memory bhar jata hai.

### ✅ Stateless (Naya MCP Style)
```
Client → Server: "X-API-Key: sk-live-xxx, Yeh lo product_id, quantity, email"
Server: "OK, process kar diya. Kuch yaad nahi rakha."
```
**Benefit:** Any server can handle any request. Round-robin load balancing. No headaches.

---

## 🏗️ Project Structure

```
stateless_django/
├── manage.py
├── requirements.txt
├── stateless_project/
│   ├── __init__.py
│   ├── settings.py      ← NO sessions, NO CSRF, NO session middleware
│   ├── urls.py
│   └── wsgi.py
└── stateless_app/
    ├── __init__.py
    ├── auth.py          ← API Key auth (no session cookies)
    ├── models.py        ← Product, Order
    ├── views.py         ← Stateless API endpoints
    ├── urls.py
    └── migrations/
```

---

## ⚙️ Key Stateless Settings

### `settings.py` — Sessions Removed!

```python
# REMOVED from MIDDLEWARE:
# 'django.contrib.sessions.middleware.SessionMiddleware',
# 'django.middleware.csrf.CsrfViewMiddleware',
# 'django.contrib.auth.middleware.AuthenticationMiddleware',
# 'django.contrib.messages.middleware.MessageMiddleware',

# REMOVED from INSTALLED_APPS:
# 'django.contrib.sessions',
# 'django.contrib.messages',
# 'django.contrib.admin',  # (optional, but removed for pure stateless)

# Explicitly disable sessions
SESSION_ENGINE = None
SESSION_COOKIE_NAME = None
```

### Authentication: API Key in Header

```python
REST_FRAMEWORK = {
    'DEFAULT_AUTHENTICATION_CLASSES': [
        'stateless_app.auth.APIKeyAuthentication',  # Custom, no sessions
    ],
}
```

---

## 🚀 Quick Start

### 1. Install Dependencies
```bash
cd stateless_django
pip install -r requirements.txt
```

### 2. Run Migrations
```bash
python manage.py migrate
```

### 3. Create Sample Data (Optional)
```bash
python manage.py shell
```
```python
from stateless_app.models import Product
Product.objects.create(name="Chai", price=10.00, stock=100)
Product.objects.create(name="Biscuit", price=5.00, stock=200)
Product.objects.create(name="Bread", price=25.00, stock=50)
exit()
```

### 4. Run Server
```bash
python manage.py runserver
```

---

## 🧪 Testing the API

### Health Check (No Auth)
```bash
curl http://localhost:8000/api/health/
```
Response:
```json
{
  "status": "healthy",
  "mode": "stateless",
  "session": "nahi_hai",
  "message": "Koi bhi server request handle kar sakta hai. Round-robin chalega!"
}
```

### List Products (With API Key)
```bash
curl -H "X-API-Key: sk-live-demo-key-change-me"      http://localhost:8000/api/products/
```

### Create Product (With API Key)
```bash
curl -X POST      -H "X-API-Key: sk-live-demo-key-change-me"      -H "Content-Type: application/json"      -d '{"name":"Parle-G","price":5,"stock":500}'      http://localhost:8000/api/products/create/
```

### Place Order (With API Key + Full Context)
```bash
curl -X POST      -H "X-API-Key: sk-live-demo-key-change-me"      -H "Content-Type: application/json"      -d '{"product_id":1,"quantity":2,"customer_email":"a@b.com"}'      http://localhost:8000/api/orders/create/
```

---

## 🎯 Why This is Stateless

| Feature | Stateful (Old) | Stateless (This App) |
|---------|---------------|---------------------|
| **Session ID** | Cookie mein store | ❌ Nahi hai |
| **Auth** | Session cookie | ✅ API Key in every request |
| **CSRF** | Needed | ❌ Disabled |
| **Load Balancer** | Sticky sessions needed | ✅ Plain Round-Robin |
| **Server Memory** | Session store bhar jata hai | ✅ Zero session memory |
| **Scalability** | Complex | ✅ Just add more servers |
| **Request Format** | "Cookie: sessionid=abc" | ✅ "X-API-Key: xxx + full data" |

---

## 🔐 Production Notes

1. **Change API Key:** Update `STATELESS_API_KEY` in `settings.py` or use environment variables.
2. **Use HTTPS:** Always send API keys over HTTPS.
3. **Rate Limiting:** Already configured in `REST_FRAMEWORK` settings.
4. **Database:** Use PostgreSQL instead of SQLite for production.
5. **Idempotency:** For payments/orders, add `Idempotency-Key` header to prevent duplicates.

---

## 📜 License

MIT — Use karo, modify karo, deploy karo. Session ki tension mat lo! 😄
