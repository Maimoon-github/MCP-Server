"""Project URL Configuration — Stateless"""
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('api/', include('stateless_app.urls')),
]
