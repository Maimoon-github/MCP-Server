"""
Django settings for stateless project.
NO SESSIONS. NO CSRF. Every request is self-contained.
"""

from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

SECRET_KEY = 'change-me-in-production'
DEBUG = True

ALLOWED_HOSTS = ['*']

# ==========================
# INSTALLED APPS
# ==========================
INSTALLED_APPS = [
    'django.contrib.contenttypes',   # Needed for models
    'django.contrib.auth',           # Needed for User model (but NOT sessions)
    'django.contrib.staticfiles',
    'rest_framework',
    'stateless_app',
]

# ==========================
# MIDDLEWARE — NO SESSIONS!
# ==========================
MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.middleware.common.CommonMiddleware',
    # REMOVED: 'django.contrib.sessions.middleware.SessionMiddleware',
    # REMOVED: 'django.middleware.csrf.CsrfViewMiddleware',
    # REMOVED: 'django.contrib.auth.middleware.AuthenticationMiddleware',
    # REMOVED: 'django.contrib.messages.middleware.MessageMiddleware',
]

ROOT_URLCONF = 'stateless_project.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
            ],
        },
    },
]

WSGI_APPLICATION = 'stateless_project.wsgi.application'

# ==========================
# DATABASE
# ==========================
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
    }
}

# ==========================
# NO SESSIONS CONFIG
# ==========================
# Explicitly disable sessions
SESSION_ENGINE = None
SESSION_COOKIE_NAME = None

# ==========================
# REST FRAMEWORK — Stateless
# ==========================
REST_FRAMEWORK = {
    'DEFAULT_AUTHENTICATION_CLASSES': [
        # JWT or API Key — no session cookie auth
        'stateless_app.auth.APIKeyAuthentication',
    ],
    'DEFAULT_PERMISSION_CLASSES': [
        'rest_framework.permissions.IsAuthenticated',
    ],
    'DEFAULT_RENDERER_CLASSES': [
        'rest_framework.renderers.JSONRenderer',
    ],
    'DEFAULT_PARSER_CLASSES': [
        'rest_framework.parsers.JSONParser',
    ],
    # No session-based throttling tied to session IDs
    'DEFAULT_THROTTLE_CLASSES': [
        'rest_framework.throttling.AnonRateThrottle',
        'rest_framework.throttling.UserRateThrottle',
    ],
    'DEFAULT_THROTTLE_RATES': {
        'anon': '100/minute',
        'user': '1000/minute',
    },
}

# ==========================
# STATIC / MEDIA
# ==========================
STATIC_URL = 'static/'

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

# API Key for demo (in production, use env vars / DB)
STATELESS_API_KEY = "sk-live-demo-key-change-me"
