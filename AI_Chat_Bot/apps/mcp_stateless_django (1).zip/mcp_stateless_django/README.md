# MCP 2026 Stateless Django Server

A production-ready, stateless Django application implementing the **MCP 2026-07-28 Protocol**.

> **Har request apne aap mein poori hai.**  
> Every request is self-contained. No sessions. No state. Simple. Scalable. Reliable.

---

## Features

- **Stateless Architecture**: No `initialize` handshake, no `Mcp-Session-Id`, no session storage
- **Automatic Web Search**: Detects temporal queries (`latest`, `2026`, `update`) and auto-enhances them
- **Tasks Extension**: Long-running operations via shared database storage
- **Protocol Version Negotiation**: Validates `Mcp-Protocol-Version` header and `_meta`
- **Load Balancer Ready**: Plain Round-Robin compatible — no sticky sessions required

---

## Quick Start

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Configure Environment
```bash
cp .env.example .env
# Edit .env with your settings
```

### 3. Run Migrations
```bash
python manage.py migrate
```

### 4. Start Server
```bash
python manage.py runserver 0.0.0.0:8000
```

---

## API Endpoints

### Health Check (GET)
```bash
curl http://localhost:8000/mcp/
```

### JSON-RPC Methods (POST)
```bash
curl -X POST http://localhost:8000/mcp/ \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer dev-api-key-change-me" \
  -H "Mcp-Protocol-Version: 2026-07-28" \
  -d '{
    "jsonrpc": "2.0",
    "id": 1,
    "method": "tools/list",
    "params": {}
  }'
```

### Supported Methods
| Method | Description |
|--------|-------------|
| `server/discover` | Capability advertisement |
| `tools/list` | List available tools |
| `tools/call` | Execute web search or get latest updates |
| `resources/list` | List available resources |
| `resources/read` | Read protocol documentation |
| `tasks/create` | Create long-running task |
| `tasks/get` | Poll task status |
| `tasks/cancel` | Cancel a task |

---

## Web Search Tools

### `web_search`
Performs a web search with automatic context detection.

```json
{
  "method": "tools/call",
  "params": {
    "name": "web_search",
    "arguments": {
      "query": "latest AI updates",
      "num_results": 5,
      "auto_context": true
    }
  }
}
```

### `get_latest_updates`
Automatically retrieves latest updates for a topic.

```json
{
  "method": "tools/call",
  "params": {
    "name": "get_latest_updates",
    "arguments": {
      "topic": "MCP protocol",
      "source": "all"
    }
  }
}
```

---

## Architecture

```
┌─────────────┐     ┌─────────────────────┐     ┌─────────────┐
│   Client    │────▶│  Load Balancer      │────▶│  Server A   │
│  (AI Tool)  │     │  (Round-Robin)      │     │  (Stateless)│
└─────────────┘     └─────────────────────┘     └──────┬──────┘
                                                       │
                              ┌────────────────────────┘
                              ▼
                        ┌─────────────┐
                        │ Shared DB   │
                        │ (Tasks)     │
                        └─────────────┘
```

---

## Stateless Guarantees

- `request.session = None` — explicitly disabled in middleware
- No `Mcp-Session-Id` header processing
- All state travels in `_meta` per request
- Any server instance can handle any request
- Horizontal scaling without sticky sessions

---

## License

MIT
