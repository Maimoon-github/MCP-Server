# Resources Reference

> Auto-generated catalog of all built-in resources available in the Universal MCP Server.

---

## Overview

Resources are **read-only data sources** the AI host can access via URI. They provide context, configuration, and state without side effects.

| URI Scheme | Resource | Description |
|------------|----------|-------------|
| `file://` | File Content | Read any file within the sandbox |
| `env://` | Environment Variables | Read system environment variables |
| `system://` | System Information | CPU, memory, disk, network stats |
| `log://` | Application Logs | Read structured log files |

---

## Resource Model

Each resource implements:

```python
class BaseResource(ABC):
    uri: str              # Unique URI (e.g., "file:///path/to/file")
    name: str             # Human-readable name
    description: str      # LLM-friendly description
    mime_type: str        # MIME type for content negotiation

    @abstractmethod
    async def read(self) -> bytes | str:
        """Return resource contents."""
        ...
```

Resources are **read-only by design**. For write operations, use [Tools](tools_reference.md).

---

## File Resources (`file://`)

### URI Format

```
file:///absolute/path/to/file
```

### Examples

| URI | Description |
|-----|-------------|
| `file:///home/user/project/main.py` | Python source file |
| `file:///etc/hosts` | System hosts file (if in sandbox) |
| `file:///var/log/nginx/access.log` | Web server access log |

### Security

- Path must be within configured `sandbox_paths`
- Symlinks are resolved and validated against sandbox
- Binary files returned as base64 with `mime_type: application/octet-stream`
- Max file size: 10MB (configurable)

### MIME Type Detection

| Extension | MIME Type |
|-----------|-----------|
| `.py` | `text/x-python` |
| `.js` | `application/javascript` |
| `.json` | `application/json` |
| `.md` | `text/markdown` |
| `.html` | `text/html` |
| `.csv` | `text/csv` |
| `.png` | `image/png` |
| `.jpg` | `image/jpeg` |

---

## Environment Resources (`env://`)

### URI Format

```
env://VARIABLE_NAME
```

### Examples

| URI | Returns |
|-----|---------|
| `env://HOME` | `/home/user` |
| `env://PATH` | `/usr/local/bin:/usr/bin:/bin` |
| `env://PYTHONPATH` | Python module search path |

### Security

- Secrets are **redacted** by default
- Redaction patterns: `*KEY*`, `*SECRET*`, `*TOKEN*`, `*PASSWORD*`, `*API*`
- To access secrets, add to `env_allowlist` in config (not recommended)

---

## System Resources (`system://`)

### URI Format

```
system://<metric>
```

### Available Metrics

| URI | Description | Format |
|-----|-------------|--------|
| `system://cpu` | CPU usage per core | JSON |
| `system://memory` | RAM usage (total, used, free, percent) | JSON |
| `system://disk` | Disk usage per mount point | JSON |
| `system://network` | Network interfaces and IO stats | JSON |
| `system://processes` | Top processes by CPU/memory | JSON |
| `system://uptime` | System uptime in seconds | JSON |
| `system://load` | Load averages (1m, 5m, 15m) | JSON |

### Example: `system://memory`

```json
{
  "total": 17179869184,
  "available": 8589934592,
  "used": 7516192768,
  "free": 9663676416,
  "percent": 50.0,
  "unit": "bytes"
}
```

---

## Log Resources (`log://`)

### URI Format

```
log://<app>/<date>
```

### Examples

| URI | Description |
|-----|-------------|
| `log://universal_mcp/2026-06-01` | Server logs for today |
| `log://nginx/2026-05-30` | Nginx logs for specific date |
| `log://app/latest` | Most recent log entries |

### Features

- Automatic log rotation awareness
- Structured JSON parsing for JSON-formatted logs
- Filtering by log level (error, warn, info, debug)
- Pagination support for large logs

---

## Resource Discovery

The server exposes a `resources/list` endpoint that returns all registered resources:

```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "resources/list",
  "result": {
    "resources": [
      {
        "uri": "file:///home/user/project/README.md",
        "name": "README.md",
        "description": "Project documentation",
        "mimeType": "text/markdown"
      },
      {
        "uri": "system://memory",
        "name": "System Memory",
        "description": "Current RAM usage statistics",
        "mimeType": "application/json"
      }
    ]
  }
}
```

Resources can be **dynamic** — they may appear or disappear based on filesystem state, system events, or configuration changes.

---

## Custom Resources

```python
from universal_mcp.primitives.resources.base import BaseResource
from universal_mcp.primitives.resources.registry import resource_registry

class GitStatusResource(BaseResource):
    uri = "git://status"
    name = "Git Status"
    description = "Current git repository status"
    mime_type = "application/json"

    async def read(self):
        import subprocess
        result = subprocess.run(
            ["git", "status", "--porcelain"],
            capture_output=True, text=True, cwd="/home/user/project"
        )
        return result.stdout.encode()

resource_registry.register(GitStatusResource())
```

---

*Auto-generated from source. Last updated: 2026-06-01*
